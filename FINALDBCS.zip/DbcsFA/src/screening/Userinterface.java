package screening;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.xmp.options.Options;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class Userinterface {

	/**********************************************************************************************
	 * 
	 * Attributes
	 * 
	 **********************************************************************************************/

	/*
	 * Constants used to parameterize the graphical user interface. We do not use a
	 * layout manager for this application. Rather we manually control the location
	 * of each graphical element for exact control of the look and feel.
	 */
	private final double BUTTON_WIDTH = 60;
	private final double BUTTON_OFFSET = BUTTON_WIDTH / 2;

	// These are the application values required by the user interface
	

	

	
	Button add_record = new Button("Add Record");
	Button modify_record = new Button("modify Record");
	Button delete_record = new Button("delete Record");
	

 Button submit = new Button("submit");
 ComboBox<String> combo_box2;
 
 
 TextField reg_no = new TextField("");
 TextField roll_no = new TextField("");
    TextField name = new TextField("");
	TextField father_name = new TextField("");
	TextField mother_name = new TextField("");
	TextField course = new TextField("");
	TextField semester = new TextField("");
	TextField year = new TextField("");
	Label Student_Enrollment = new Label("Student Enrollment");
	TextField student_name = new TextField();
	
	
	String s;
	String y;
	Connection con;

	private double buttonSpace;

	public Userinterface(Pane theRoot, Stage Stage) {

		// There are five gaps. Compute the button space accordingly.
		buttonSpace = mainline.WINDOW_WIDTH / 5;

		// Label theScene with the name of the mainline, centered at the top of the pane
		
		add_record.setLayoutX(100);
		add_record.setLayoutY(50);
		
		modify_record.setLayoutX(100);
		modify_record.setLayoutY(100);
		
		delete_record.setLayoutX(100);
		delete_record.setLayoutY(150);		
		
		add_record.setOnAction((event) -> {
			try {
				add_record(Stage);
			} catch (FileNotFoundException e) {

				e.printStackTrace();
			}

		});
		
		
		delete_record.setOnAction((event) -> {
			try {
				delete_record(Stage);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		});
		theRoot.getChildren().addAll( add_record,modify_record,delete_record);

	}
	
	
	
	
	private void delete_record(Stage stage1) throws ClassNotFoundException, SQLException, FileNotFoundException {
		stage1.setTitle("Add Record");

		Pane theRoot1 = new Pane(); 
		
		File theDirectory = new File("RespositoryOut");
    	if (!theDirectory.exists()) {
    	theDirectory.mkdir();
    	theDirectory.setReadable(true);
    	theDirectory.setWritable(true);
    	System.out.println("The directory was created");
    	}
    	
		 
		String g = null;
		String url = "jdbc:mysql://localhost/db?autoReconnect=true&useSSL=false";
		String uName = "root";
		String pass = "anshul@1";
		String query = "select roll_no from student";

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, uName, pass);
		
		
		Statement st = con.createStatement();
		
		
		ResultSet rs = st.executeQuery(query);
		
		File theDataFile = new File("RespositoryOut/data.txt");
		
		while(rs.next()) {
			
			int name = rs.getInt("roll_no");
			
			
			 g = Integer.toString(name);
			 
			 

		    	
				
		    	
		    
		    	
		    	
		    	
		    	
		    	
		    	
		    	
		    	
		    	// Set up the file writer and then write out the dictionary
		    	try (FileWriter writer = new FileWriter(theDataFile,true)) {
		    	// Actually write out the Dictionary
		    	
		    	writer.write(g+",");
		    	
		    
		    	
		    	
		    	
		    	
		    	writer.close();
		    	} catch (IOException e) {
	
		    	}
				
			
			 
			
				
			
		
			 
			
			
			
		}
		rs.close();
		st.close();
		con.close();
		
		File t = new File("RespositoryOut/data.txt");
Scanner scan = new Scanner(t);
		while(scan.hasNextLine()) {
			
			String[] tokens = scan.nextLine().split(",");
		combo_box2 = new ComboBox<String>(FXCollections.observableArrayList(tokens));
		
		}
		
		
		
		
		student_name.setLayoutX(130);
		student_name.setLayoutY(150);
		
		combo_box2.setLayoutX(130);
		combo_box2.setLayoutY(100);
		
		
		
		Button delete = new Button("Delete Record");
		
		delete.setLayoutX(130);
		delete.setLayoutY(200);
		
		
		
		combo_box2.getSelectionModel().selectedItemProperty().addListener((Options, oldValue, newValue)->{
			try {
				name();
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		
		delete.setOnAction((event)->{
			try {
				delete();
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		
		
		
		
		
		
		
		Scene scene = new Scene(theRoot1, 400, 350); // Creating a scene object

		stage1.setScene(scene); // Adding scene to the stage
		theRoot1.getChildren().addAll(combo_box2,student_name, delete);

		stage1.show();
	
	}




	




	private void name() throws ClassNotFoundException, SQLException {
		
		String url = "jdbc:mysql://localhost/db?autoReconnect=true&useSSL=false";
		String uName = "root";
		String pass = "anshul@1";
		String query = "select name from student where roll_no="+combo_box2.getSelectionModel().getSelectedItem();

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, uName, pass);
		
		
		Statement st = con.createStatement();
		
		
		
		ResultSet rs = st.executeQuery(query);
		while(rs.next()) {
			String name = rs.getString("name");
			student_name.setText(name);
		}
		con.commit();
		
		con.close();

		System.out.println("Success import excel to mysql table");
		
	}




	private void delete() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost/db?autoReconnect=true&useSSL=false", "root", "anshul@1");
		con.setAutoCommit(false);
		PreparedStatement pstm = null;
		
		String sql = "delete from student where roll_no="+combo_box2.getSelectionModel().getSelectedItem();
			
		pstm = (PreparedStatement) con.prepareStatement(sql);
		pstm.execute();
		
		
			
		

			
		con.commit();
		
		con.close();

		System.out.println("Success import excel to mysql table");
		
	}




	private void add_record(Stage theStage) throws FileNotFoundException { // set stage
		theStage.setTitle("Add Record");

		Pane theRoot = new Pane(); // create pane

		
		setupLabelUI(Student_Enrollment, "Arial", 24, mainline.WINDOW_WIDTH, Pos.CENTER, 50, 10);
		
		Label name_label = new Label("Enter Name");
		
		name_label.setLayoutX(50);
		name_label.setLayoutY(105);
		
		name.setLayoutX(180);
		name.setLayoutY(100);
		
		
		Label father_label = new Label("Enter Father Name");
		
		father_label.setLayoutX(50);
		father_label.setLayoutY(135);
		
		father_name.setLayoutX(180);
		father_name.setLayoutY(130);
		
Label mother_label = new Label("Enter Mother Name");
		
		mother_label.setLayoutX(50);
		mother_label.setLayoutY(165);
		
		mother_name.setLayoutX(180);
		mother_name.setLayoutY(160);
		
		
Label course_label = new Label("Enter Course Name");
		
		course_label.setLayoutX(50);
		course_label.setLayoutY(195);
		
		course.setLayoutX(180);
		course.setLayoutY(190);
		
		
Label semester_label = new Label("Enter Semester No.");
		
		semester_label.setLayoutX(50);
		semester_label.setLayoutY(225);
		
		semester.setLayoutX(180);
		semester.setLayoutY(220);
		
		
  Label year_label = new Label("Enter Year");
		
		year_label.setLayoutX(50);
		year_label.setLayoutY(255);
		
		year.setLayoutX(180);
		year.setLayoutY(250);
		
		
		submit.setLayoutX(150);
		submit.setLayoutY(300);

		submit.setOnAction((event)->{
		try {
			submit();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		});
		

		

		// Create a combo box for year
		

		Scene scene = new Scene(theRoot, 400, 350); // Creating a scene object

		theStage.setScene(scene); // Adding scene to the stage
		theRoot.getChildren().addAll(name_label,father_label, mother_label,course_label,semester_label,year_label,Student_Enrollment, name, father_name, mother_name, course, semester, year, submit);

		theStage.show(); // Displaying the contents of the stage
	}

	private void submit() throws ClassNotFoundException, SQLException {
		
			
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection(
						"jdbc:mysql://localhost/db?autoReconnect=true&useSSL=false", "root", "anshul@1");
				con.setAutoCommit(false);
				PreparedStatement pstm = null;
				
				String sql = "INSERT INTO student_reg (name,father_name,mother_name,course,year) VALUES('" +  name.getText() + "','" + father_name.getText() + "','" + mother_name.getText() + "','"
						+ course.getText() + "','" + year.getText() + "')";
					
				pstm = (PreparedStatement) con.prepareStatement(sql);
				pstm.execute();
				
				
					
				

					
				con.commit();
				
				con.close();

				System.out.println("Success import excel to mysql table");
			
submit2();
		
			

			
		
	}

	private void submit2() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost/db?autoReconnect=true&useSSL=false", "root", "anshul@1");
		con.setAutoCommit(false);
		PreparedStatement pstm = null;



		

		String sql = "INSERT INTO student (reg_no,name,father_name,mother_name,course,semester,year) VALUES("+"(Select reg_no from student_reg where name ="+ "'"+name.getText()+"'"+")" + ",'"+ name.getText() + "','" + father_name.getText() + "','" + mother_name.getText() + "','"
				+ course.getText() + "','" +  semester.getText() + "','" + year.getText() + "')";
			
		pstm = (PreparedStatement) con.prepareStatement(sql);
		System.out.println(pstm); 
		pstm.execute();

			
		con.commit();

		con.close();

		System.out.println("Success import excel to mysql table");
		
	}




	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e) {
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}

	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

	/**********************************************************************************************
	 * 
	 * User Interface Actions
	 * 
	 **********************************************************************************************/

	

}